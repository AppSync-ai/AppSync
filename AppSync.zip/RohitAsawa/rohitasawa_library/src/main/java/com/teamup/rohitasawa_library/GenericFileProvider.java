package com.teamup.rohitasawa_library;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {}