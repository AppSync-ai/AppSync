package com.teamup.rohitasawa_library;

import android.content.Context;

public class Commons {
    public static Context context= null;
    public static String jsonResult="";
}
